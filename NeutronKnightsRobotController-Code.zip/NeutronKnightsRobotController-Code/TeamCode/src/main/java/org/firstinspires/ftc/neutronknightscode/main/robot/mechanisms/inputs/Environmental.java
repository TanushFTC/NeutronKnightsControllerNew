package org.firstinspires.ftc.neutronknightscode.main.robot.mechanisms.inputs;

import com.qualcomm.robotcore.hardware.HardwareMap;

public class Environmental implements Input{
    @Override
    public void init(HardwareMap hardwareMap) {

    }

    @Override
    public void get() {

    }
}
