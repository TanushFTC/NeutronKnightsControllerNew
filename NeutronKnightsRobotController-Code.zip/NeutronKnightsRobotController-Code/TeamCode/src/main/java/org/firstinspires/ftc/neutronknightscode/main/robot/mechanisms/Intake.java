package org.firstinspires.ftc.neutronknightscode.main.robot.mechanisms;

import com.qualcomm.robotcore.hardware.HardwareMap;

public class Intake implements Mechanism {
    @Override
    public void init(HardwareMap hardwareMap) {

    }
}
