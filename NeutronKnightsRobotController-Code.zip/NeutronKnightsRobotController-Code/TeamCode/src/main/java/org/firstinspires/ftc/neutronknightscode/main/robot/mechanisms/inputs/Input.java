package org.firstinspires.ftc.neutronknightscode.main.robot.mechanisms.inputs;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import org.firstinspires.ftc.neutronknightscode.main.robot.mechanisms.Mechanism;

public interface Input extends Mechanism {
    public void get();
}
