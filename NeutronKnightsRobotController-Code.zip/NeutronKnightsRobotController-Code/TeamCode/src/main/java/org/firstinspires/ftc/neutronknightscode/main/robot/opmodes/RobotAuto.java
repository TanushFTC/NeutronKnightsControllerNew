package org.firstinspires.ftc.neutronknightscode.main.robot.opmodes;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;

@Autonomous
public class RobotAuto extends RobotOpMode {
    @Override
    public void loop() {

    }
}

